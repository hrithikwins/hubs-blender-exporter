from . import (lightmap)


def register():
    lightmap.register()


def unregister():
    lightmap.unregister()
